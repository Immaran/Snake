﻿namespace SnakeWPF
{
    class Punkt
    {
        public int x;
        public int y;

        public Punkt()
        {
            x = 0;
            y = 0;
        }
        public Punkt(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

        public void Add(Punkt punkt)
        {
            this.x += punkt.x;
            this.y += punkt.y;
        }

        public bool Equal(Punkt punkt)
        {
            if(this.x == punkt.x && this.y == punkt.y)
            {
                return true;
            }
            return false;
        }
    }
}
